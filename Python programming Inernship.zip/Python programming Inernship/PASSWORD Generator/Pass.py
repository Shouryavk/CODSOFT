import random
import string

def generate_password(length, complexity):
    characters = string.ascii_letters  # Includes both lowercase and uppercase letters

    if complexity > 1:
        characters += string.digits  # Adds digits if complexity > 1
    
    if complexity > 2:
        characters += string.punctuation  # Adds special characters if complexity > 2

    return ''.join(random.choice(characters) for _ in range(length))

def get_user_input():
    while True:
        try:
            length = int(input("Enter the desired length of the password: "))
            if length < 1:
                print("Password length must be at least 1.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter a positive integer.")

    while True:
        try:
            complexity = int(input("Enter the complexity level (1: Letters, 2: Letters and Digits, 3: Letters, Digits, and Special Characters): "))
            if complexity not in [1, 2, 3]:
                print("Invalid complexity level. Please enter 1, 2, or 3.")
                continue
            break
        except ValueError:
            print("Invalid input. Please enter an integer (1, 2, or 3).")

    return length, complexity

def main():
    print("Password Generator")
    length, complexity = get_user_input()
    password = generate_password(length, complexity)
    print(f"Generated Password: {password}")

if __name__ == "__main__":
    main()
